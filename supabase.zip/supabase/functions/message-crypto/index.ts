import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ─── BB84 Quantum Key Distribution Simulation ───
function simulateBB84(numBits = 256): number[] {
  const aliceBits = Array.from({ length: numBits }, () => Math.round(Math.random()));
  const aliceBases = Array.from({ length: numBits }, () => Math.round(Math.random()));
  const bobBases = Array.from({ length: numBits }, () => Math.round(Math.random()));

  const siftedBits: number[] = [];
  for (let i = 0; i < numBits; i++) {
    if (aliceBases[i] === bobBases[i]) {
      siftedBits.push(aliceBits[i]);
    }
  }
  return siftedBits.slice(0, 128);
}

// ─── Derive AES-GCM key from raw bytes ───
async function deriveKey(keyMaterial: Uint8Array, salt: Uint8Array): Promise<CryptoKey> {
  const baseKey = await crypto.subtle.importKey("raw", keyMaterial, "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

// ─── AES-GCM encrypt/decrypt helpers ───
async function aesEncrypt(key: CryptoKey, plaintext: string): Promise<{ iv: string; ciphertext: string }> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encoded);
  return {
    iv: btoa(String.fromCharCode(...iv)),
    ciphertext: btoa(String.fromCharCode(...new Uint8Array(encrypted))),
  };
}

async function aesDecrypt(key: CryptoKey, iv: string, ciphertext: string): Promise<string> {
  const ivBytes = Uint8Array.from(atob(iv), (c) => c.charCodeAt(0));
  const ctBytes = Uint8Array.from(atob(ciphertext), (c) => c.charCodeAt(0));
  const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: ivBytes }, key, ctBytes);
  return new TextDecoder().decode(decrypted);
}

// ─── Protocol Implementations (from Capstone.ipynb) ───

async function classicalEncrypt(message: string) {
  const startTime = performance.now();

  // Generate random AES key (Classical / Fernet-equivalent)
  const rawKey = crypto.getRandomValues(new Uint8Array(32));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await deriveKey(rawKey, salt);
  const { iv, ciphertext } = await aesEncrypt(key, message);

  const timeMs = performance.now() - startTime;
  return {
    protocol: "Classical (AES)",
    ciphertext,
    encryption_data: {
      algorithm: "AES-256-GCM",
      key: btoa(String.fromCharCode(...rawKey)),
      salt: btoa(String.fromCharCode(...salt)),
      iv,
    },
    metrics: {
      time_ms: timeMs,
      security_level: 0.3,
      quantum_resistant: false,
      energy_cost: 0.1,
    },
  };
}

async function quantumEncrypt(message: string) {
  const startTime = performance.now();

  // BB84 Quantum Key Distribution simulation
  const quantumBits = simulateBB84(256);

  if (quantumBits.length < 32) {
    // Fallback if insufficient sifted bits (rare)
    return classicalEncrypt(message);
  }

  // Derive key from quantum bits: key_string → SHA-256 → PBKDF2
  const keyString = quantumBits.slice(0, 32).join("");
  const keyHash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(keyString));
  const quantumKey = new Uint8Array(keyHash);

  const salt = new TextEncoder().encode("quantum");
  const key = await deriveKey(quantumKey, salt);
  const { iv, ciphertext } = await aesEncrypt(key, message);

  const timeMs = performance.now() - startTime;
  return {
    protocol: "Quantum (BB84)",
    ciphertext,
    encryption_data: {
      algorithm: "BB84-AES-256-GCM",
      quantum_bits: quantumBits.slice(0, 32),
      salt: btoa(String.fromCharCode(...salt)),
      iv,
      qber: Math.random() * 0.05, // Simulated Quantum Bit Error Rate
    },
    metrics: {
      time_ms: timeMs,
      security_level: 1.0,
      quantum_resistant: true,
      energy_cost: 0.8,
    },
  };
}

async function hybridEncrypt(message: string) {
  const startTime = performance.now();

  // Classical key
  const classicalKey = crypto.getRandomValues(new Uint8Array(32));

  // Quantum key via BB84
  const quantumBits = simulateBB84(128);
  let finalKey: Uint8Array;
  let protocolType: string;
  let securityLevel: number;

  if (quantumBits.length >= 32 && Math.random() < 0.95) {
    // Full hybrid: KG = H(K1 ⊕ K2) — equation 1 from the paper
    const keyString = quantumBits.slice(0, 32).join("");
    const quantumKeyHash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(keyString));
    const quantumKey = new Uint8Array(quantumKeyHash).slice(0, 32);

    // XOR combination
    const xorResult = new Uint8Array(32);
    for (let i = 0; i < 32; i++) {
      xorResult[i] = classicalKey[i] ^ quantumKey[i];
    }
    const finalHash = await crypto.subtle.digest("SHA-256", xorResult);
    finalKey = new Uint8Array(finalHash);
    protocolType = "Hybrid (Kyber)";
    securityLevel = 0.8;
  } else {
    // Fallback to classical only
    finalKey = classicalKey;
    protocolType = "Hybrid (Kyber)";
    securityLevel = 0.4;
  }

  const salt = new TextEncoder().encode("hybrid");
  const key = await deriveKey(finalKey, salt);
  const { iv, ciphertext } = await aesEncrypt(key, message);

  const timeMs = performance.now() - startTime;
  return {
    protocol: protocolType,
    ciphertext,
    encryption_data: {
      algorithm: "Hybrid-XOR-AES-256-GCM",
      classical_key: btoa(String.fromCharCode(...classicalKey)),
      quantum_bits: quantumBits.slice(0, 32),
      salt: btoa(String.fromCharCode(...salt)),
      iv,
      full_hybrid: securityLevel > 0.5,
    },
    metrics: {
      time_ms: timeMs,
      security_level: securityLevel,
      quantum_resistant: securityLevel > 0.5,
      energy_cost: 0.5,
    },
  };
}

// ─── Decryption ───

async function decryptMessage(encryptionData: any, ciphertext: string): Promise<string> {
  const { algorithm, iv } = encryptionData;

  let keyMaterial: Uint8Array;
  let salt: Uint8Array;

  if (algorithm === "AES-256-GCM") {
    // Classical
    keyMaterial = Uint8Array.from(atob(encryptionData.key), (c) => c.charCodeAt(0));
    salt = Uint8Array.from(atob(encryptionData.salt), (c) => c.charCodeAt(0));
  } else if (algorithm === "BB84-AES-256-GCM") {
    // Quantum — re-derive key from stored quantum bits
    const keyString = encryptionData.quantum_bits.join("");
    const keyHash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(keyString));
    keyMaterial = new Uint8Array(keyHash);
    salt = new TextEncoder().encode("quantum");
  } else if (algorithm === "Hybrid-XOR-AES-256-GCM") {
    // Hybrid — re-derive XOR'd key
    const classicalKey = Uint8Array.from(atob(encryptionData.classical_key), (c) => c.charCodeAt(0));

    if (encryptionData.full_hybrid && encryptionData.quantum_bits?.length >= 32) {
      const keyString = encryptionData.quantum_bits.join("");
      const quantumKeyHash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(keyString));
      const quantumKey = new Uint8Array(quantumKeyHash).slice(0, 32);

      const xorResult = new Uint8Array(32);
      for (let i = 0; i < 32; i++) {
        xorResult[i] = classicalKey[i] ^ quantumKey[i];
      }
      const finalHash = await crypto.subtle.digest("SHA-256", xorResult);
      keyMaterial = new Uint8Array(finalHash);
    } else {
      keyMaterial = classicalKey;
    }
    salt = new TextEncoder().encode("hybrid");
  } else {
    throw new Error(`Unknown algorithm: ${algorithm}`);
  }

  const key = await deriveKey(keyMaterial, salt);
  return aesDecrypt(key, iv, ciphertext);
}

// ─── Main Handler ───

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, message, threat_level, encryption_data, ciphertext, messages } = await req.json();

    if (action === "encrypt") {
      let result;
      if (threat_level >= 0.8) {
        result = await quantumEncrypt(message);
      } else if (threat_level >= 0.4) {
        result = await hybridEncrypt(message);
      } else {
        result = await classicalEncrypt(message);
      }

      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "decrypt") {
      // Single message
      if (encryption_data && ciphertext) {
        const plaintext = await decryptMessage(encryption_data, ciphertext);
        return new Response(JSON.stringify({ plaintext }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Batch decrypt
      if (messages && Array.isArray(messages)) {
        const results = await Promise.all(
          messages.map(async (msg: any) => {
            if (msg.encryption_data && msg.content) {
              try {
                const plaintext = await decryptMessage(msg.encryption_data, msg.content);
                return { ...msg, content: plaintext };
              } catch {
                return { ...msg, content: "[Decryption failed]" };
              }
            }
            // Legacy unencrypted messages
            return msg;
          })
        );
        return new Response(JSON.stringify({ messages: results }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
